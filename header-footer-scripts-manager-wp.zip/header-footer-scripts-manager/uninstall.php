<?php 

// Prevent direct access to this file
if (!defined('WP_UNINSTALL_PLUGIN')) {
    die;
}
delete_option('hfsm_insert_header_scripts');
delete_option('hfsm_insert_footer_scripts');
delete_post_meta_by_key('_hfsm_head_scripts');
delete_post_meta_by_key('_hfsm_footer_scripts');