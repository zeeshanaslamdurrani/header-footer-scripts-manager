<?php
	/**
 * Plugin Name: Header Footer Scripts Manager
 * Plugin URI: https://metalogix.website/hfsm/
 * Description: Allows you to insert scripts to header and footer of your website
 * Version: 1.0
 * Author: pluspt2001
 * Author URI: https://metalogix.website/
 * Text Domain: header-footer-scripts-manager
 * Domain Path: /lang
 * License: GPLv2 or later
 */

/*
Header Footer Scripts Manager
Copyright (C) , Zeeshan Durrani <zeeshanaslamdurrani@gmail.com>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2, as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

	define('HFSM_PLUGIN_DIR',str_replace('\\','/',dirname(__FILE__)));
	add_action( 'init', 'init' );
	function init() {
		load_plugin_textdomain( 'header-footer-scripts-manager', false, dirname( plugin_basename ( __FILE__ ) ).'/lang' );
	}
	add_action( 'admin_init', 'admin_init');
	add_action( 'admin_menu', 'admin_menu');
	function admin_menu() 
	{
	$page = add_submenu_page( 'options-general.php', __('Header Footer Scripts Manager', 'header-footer-scripts-manager'), __('Header Footer Scripts Manager', 'header-footer-scripts-manager'), 'manage_options', __FILE__, 'hfsm_options_dashboard');
	}
	function hfsm_options_dashboard() {
				// Load options page
				require_once(HFSM_PLUGIN_DIR . '/include/hfsm_options.php');
	}	
			
	function admin_init() {
		// register settings for sitewide script
		register_setting( 'header-footer-scripts-manager', 'hfsm_insert_header_scripts', 'trim' );
		register_setting( 'header-footer-scripts-manager', 'hfsm_insert_footer_scripts', 'trim' );
		
		//setup two metaboxes one for header and another for footer
			add_meta_box('hfsm_all_post_meta1', esc_html__('Insert Scripts or Styles to &lt;header&gt;', 'header-footer-scripts-manager'), 'hfsm_meta_setup1', 'page', 'normal', 'high');
			add_meta_box('hfsm_all_post_meta2', esc_html__('Insert Scripts or Styles to &lt;footer&gt;', 'header-footer-scripts-manager'), 'hfsm_meta_setup2', 'page', 'normal', 'high');

        //save header and footer metaboxes
		add_action('save_post','hfsm_post_meta_save1');
		add_action('save_post','hfsm_post_meta_save2');
}
	
	
	function hfsm_meta_setup1() {
		global $post;
		$meta1 = get_post_meta($post->ID,'_hfsm_head_scripts',TRUE);
		
		// include html of first metabox
		include_once(HFSM_PLUGIN_DIR . '/include/meta1.php');
		
		// submit verification with nonce field
		echo '<input type="hidden" name="hfsm_post_meta_noncename1" value="' . wp_create_nonce(__FILE__) . '" />';
	}
	function hfsm_meta_setup2() {
		global $post;
		//setting up second metabox
		$meta2 = get_post_meta($post->ID,'_hfsm_footer_scripts',TRUE);
		
		// include second metabox html
		include_once(HFSM_PLUGIN_DIR . '/include/meta2.php');
		
		// nonce for verification with nonce field
		echo '<input type="hidden" name="hfsm_post_meta_noncename2" value="' . wp_create_nonce(__FILE__) . '" />';
	}
	
	function hfsm_post_meta_save1($post_id) {
		// authentication checks
		echo '<br> the post id is '.$post_id;
		// make sure data came from our meta box
		if ( ! isset( $_POST['hfsm_post_meta_noncename1'] )
		|| !wp_verify_nonce($_POST['hfsm_post_meta_noncename1'],__FILE__)) return $post_id;
		echo 'nonce is verified';
		// check user permissions
		if ( $_POST['post_type'] == 'page' ) {
			
			if (!current_user_can('edit_page', $post_id))
			return $post_id;
			
			} else {
			
			if (!current_user_can('edit_post', $post_id))
			return $post_id;
			
		}
		
		$current_data = get_post_meta($post_id, '_hfsm_head_scripts', TRUE);
		$new_data = $_POST['_hfsm_head_scripts'];
		
		if ($current_data) {
			
			if (is_null($new_data)) delete_post_meta($post_id,'_hfsm_head_scripts');
			
			else update_post_meta($post_id,'_hfsm_head_scripts',$new_data);
			
			} elseif (!is_null($new_data)) {
			
			add_post_meta($post_id,'_hfsm_head_scripts',$new_data,TRUE);
			
		}
		
		return $post_id;
	}
	function hfsm_post_meta_save2($post_id) {
		
		
		// make sure data came from our meta box
		if ( ! isset( $_POST['hfsm_post_meta_noncename2'] )
		|| !wp_verify_nonce($_POST['hfsm_post_meta_noncename2'],__FILE__)) return $post_id;
		echo 'nonce is verified';
		// check user permissions
		if ( $_POST['post_type'] == 'page' ) {
			
			if (!current_user_can('edit_page', $post_id))
			return $post_id;
			
			} else {
			
			if (!current_user_can('edit_post', $post_id))
			return $post_id;
		}
		
		$current_data = get_post_meta($post_id, '_hfsm_footer_scripts', TRUE);
		
		$new_data = $_POST['_hfsm_footer_scripts'];
		
		if ($current_data) {
			
			if (is_null($new_data)) delete_post_meta($post_id,'_hfsm_footer_scripts');
			
			else update_post_meta($post_id,'_hfsm_footer_scripts',$new_data);
			
			} elseif (!is_null($new_data)) {
			
			add_post_meta($post_id,'_hfsm_footer_scripts',$new_data,TRUE);
			
		}
		
		return $post_id;
	}
	
	//add code to <head> with wp_head hook
	add_action('wp_head','hfsm_insert_header');
	function hfsm_insert_header() {
		$meta1 = get_option( 'hfsm_insert_header_scripts', '' );
		if ( $meta1 != '' ) {
			echo $meta1, "\n";
		}
		
		
		$hfsm_post_meta = get_post_meta( get_the_ID(), '_hfsm_head_scripts' , TRUE );
		if ( is_singular() && $hfsm_post_meta != '' ) {
			echo $hfsm_post_meta['zad_header_scripts'], "\n";
		}
		
	}
	
	//add metaboxes to footer
	add_action( 'wp_footer', 'hfsm_insert_footer');
	function hfsm_insert_footer() {
		
		if ( !is_admin() && !is_feed() && !is_robots() && !is_trackback() ) {
				$text = get_option( 'hfsm_insert_footer_scripts', '' );
				$text = convert_smilies( $text );
				$text = do_shortcode( $text );

				if ( $text != '' ) {
					echo $text, "\n";
				}
			}
		
		$hfsm_post_meta = get_post_meta( get_the_ID(), '_hfsm_footer_scripts' , TRUE );
		if ( is_singular() && $hfsm_post_meta != '' ) {
			echo $hfsm_post_meta['zad_footer_scripts'], "\n";
		}
		
		}

	