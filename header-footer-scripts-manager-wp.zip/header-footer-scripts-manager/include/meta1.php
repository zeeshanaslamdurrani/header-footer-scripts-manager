 <div class="hfsm_meta_box">
	<p>
		<textarea name="_hfsm_head_scripts[zad_header_scripts]" rows="5" style="width:98%;"><?php if(!empty($meta1['zad_header_scripts'])) echo $meta1['zad_header_scripts']; ?></textarea>
	</p>

	<p><?php _e('Add some code to <code>&lt;head&gt;</code>', 'header-and-footer-scripts'); ?>.</p>
</div>
