 <div class="hfsm_meta_box">

	<p>
		<textarea name="_hfsm_footer_scripts[zad_footer_scripts]" rows="5" style="width:98%;"><?php if(!empty($meta2['zad_footer_scripts'])) echo $meta2['zad_footer_scripts']; ?></textarea>
	</p>

	<p><?php _e('Add some code to <code>&lt;footer&gt;</code>', 'header-and-footer-scripts'); ?>.</p>
</div>
